﻿using Microsoft.Extensions.Logging;
using System.ComponentModel.DataAnnotations;

namespace CourseManagerApp.Entities
{
    public enum EnrollmentConfirmationStatus
    {
        MessageNotSent = 0,
        ConfirmationMessageSent = 1,
        Confirmed = 2,
        Declined = 3
    }
    public class Student
    {
        public int StudentId { get; set; }

        [Required(ErrorMessage = "GuestName?")]
        public string? StudentName { get; set; }

        [Required(ErrorMessage = "GuestEmail?")]
        public string? StudentEmail { get; set; }

        // status
        public EnrollmentConfirmationStatus Status { get; set; } = EnrollmentConfirmationStatus.MessageNotSent;
        public int CourseId { get; set; }

        public Course? Course { get; set; }
    }
}
