﻿using System.ComponentModel.DataAnnotations;

namespace CourseManagerApp.Entities
{
    public class Course
    {
        //[Key]
        public int CourseId { get; set; }

        [Required(ErrorMessage = "What's your Course?")]
        public string? CourseName { get; set; }

        [Required(ErrorMessage = "What's your Course Instructor?")]
        public string? CourseInstructor  { get; set; }

        [Required(ErrorMessage = "What's your course start date?")]
        public DateTime? StartDate { get; set; }

        [Required(ErrorMessage = "What's your course room numebr?")]
        public string? RoomNumber { get; set; }

        public List<Student>? Students { get; set; }
    }
}
