﻿using CourseManagerApp.Entities;
using Microsoft.Extensions.Logging;

namespace CourseManagerApp.Models
{
    public class CourseViewModel
    {
        public Course? Course { get; set; }
    }
}
