﻿using CourseManagerApp.Entities;

namespace CourseManagerApp.Models
{
    public class EnrollStudentViewModel
    {
        public Student? Student { get; set; }
        public string? Response { get; set; }
    }
}
