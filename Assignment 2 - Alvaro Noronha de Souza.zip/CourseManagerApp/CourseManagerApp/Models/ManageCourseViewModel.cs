﻿using Microsoft.Extensions.Logging;
using CourseManagerApp.Entities;

namespace CourseManagerApp.Models
{
    public class ManageCourseViewModel
    {
        public Course? Course { get; set; }

        public Student? Student { get; set; }

        public int CountMessageNotSent { get; set; }
        public int CountConfirmationMessageSent { get; set; }
        public int CountConfirmed { get; set; }
        public int CountDeclined { get; set; }
    }
}
