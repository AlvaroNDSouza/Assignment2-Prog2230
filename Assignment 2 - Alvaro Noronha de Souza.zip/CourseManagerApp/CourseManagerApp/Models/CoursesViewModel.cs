﻿using CourseManagerApp.Entities;
using Microsoft.Extensions.Logging;

namespace CourseManagerApp.Models
{
    public class CoursesViewModel
    {
        public List<Course>? Courses { get; set; }
    }
}
