﻿using CourseManagerApp.Entities;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;
using System.Net;
using System.Net.Mail;

namespace CourseManagerApp.Services
{
    public class CourseManagerService : ICourseManagerService
    {
        private readonly CourseManagerDbContext _courseManagerDbContext;
        private readonly IConfiguration _configuration;

		public CourseManagerService(CourseManagerDbContext courseManagerDbContext, IConfiguration configuration)
		{
			_courseManagerDbContext = courseManagerDbContext;
			_configuration = configuration;
		}
		public List<Course> GetAllCourses()
        {
            return _courseManagerDbContext.Courses
               .Include(each => each.Students)
               .OrderByDescending(each => each.StartDate)
               .ToList();
        }

        public Course? GetCourseById(int id)
        {
            return _courseManagerDbContext.Courses
                .Include(each => each.Students)
                .FirstOrDefault(each => each.CourseId == id);
        }

        public int AddCourse(Course party)
        {
            _courseManagerDbContext.Courses.Add(party);
            _courseManagerDbContext.SaveChanges();

            return party.CourseId;
        }

        public void UpdateCourse(Course party)
        {
            _courseManagerDbContext.Courses.Update(party);
            _courseManagerDbContext.SaveChanges();
        }
        public Student? GetStudentById(int courseId, int studentId)
        {
            return _courseManagerDbContext.Students.Include(g => g.Course).FirstOrDefault(g => g.CourseId == courseId && g.StudentId == studentId);

        }
        public void UpdateConfirmationStatus(int courseId, int studentId, EnrollmentConfirmationStatus status)
        {
            var student = GetStudentById(courseId, studentId);
            if (student == null) return;
            student.Status = status;
            _courseManagerDbContext.SaveChanges();
        }
        public Course? AddStudentToCourseById(int courseId, Student student)
        {
            var party = GetCourseById(courseId);

            if (party == null) return null;

            party.Students?.Add(student);
            _courseManagerDbContext.SaveChanges();
            return party;
        }
        public void SendEnrollmentEmailByCourseId(int courseId, string scheme, string host)
        {
            //I Couln't get my account to work with smtp. But it is setup as it supposed to
            var party = GetCourseById(courseId);
            if (party == null) return;
            var students = party.Students.Where(g => g.Status == EnrollmentConfirmationStatus.MessageNotSent)
                .ToList();


            try
            {
                var smtpHost = _configuration["SmtpSettings:Host"];
                var smtpPort = _configuration["SmtpSettings:Port"];
                var fromAddress = _configuration["SmtpSettings:FromAddress"];
                var fromPassword = _configuration["SmtpSettings:FromPassword"];

                using var smtpClient = new SmtpClient(smtpHost);
                smtpClient.Port = string.IsNullOrEmpty(smtpPort) ? 587 : Convert.ToInt32(smtpPort);
                smtpClient.Credentials = new NetworkCredential(fromAddress, fromPassword);
                smtpClient.EnableSsl = true;

                foreach (var student in students)
                {
                    var responseUrl = $"{scheme}://{host}/events/{courseId}/enroll/{student.StudentId}";
                    var mailMessage = new MailMessage
                    {
                        From = new MailAddress(fromAddress),
                        Subject = $"[Action required] Confirm \"{student?.Course?.CourseName}\"",
                        Body = CreatBody(student, responseUrl),
                        IsBodyHtml = true
                    };
                    if (student.StudentEmail == null) return;
                    mailMessage.To.Add(student.StudentEmail);

                    smtpClient.Send(mailMessage);

                    student.Status = EnrollmentConfirmationStatus.ConfirmationMessageSent;
                }
                _courseManagerDbContext.SaveChanges();
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
        }
        private string CreatBody(Student student, string reponseUrl)
        {
            return $@"
                    <h1>Hello {student.StudentName}:</h1>
                    <p>
                       Your request to enroll in the course {student.Course.CourseId}
                        in room {student.Course.RoomNumber}
                        starting {student.Course.StartDate}
                        with the instructor :  {student.Course.CourseInstructor}
                    </p>
                    <p>
                        Please confrim you attendance
                    <a href={reponseUrl}>confirm your enrollment</a>
                    </p>
                    ";
        }
    }
}
