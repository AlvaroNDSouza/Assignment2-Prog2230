﻿using CourseManagerApp.Entities;
using Microsoft.Extensions.Logging;

namespace CourseManagerApp.Services
{
    public interface ICourseManagerService
    {
        public List<Course> GetAllCourses();

        public Course? GetCourseById(int id);

        public int AddCourse(Course party);

        public void UpdateCourse(Course party);
        public Student? GetStudentById(int courseId, int studentId);
        public void UpdateConfirmationStatus(int courseId, int studentId, EnrollmentConfirmationStatus status);
        public Course? AddStudentToCourseById(int courseId, Student student);
        public void SendEnrollmentEmailByCourseId(int courseId, string scheme, string host);
    }
}
